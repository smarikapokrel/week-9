			<!-- Fine print navigation -->
			<nav>
				<a href="/about/privacy-policy.php" title="Read our Privacy Policy">Privacy Policy</a> | <a href="/about/privacy-policy.php#personal-information" title="Learn about how we treat your personal information">Use of Personal Information</a> | <a href="/about/terms-of-use.php" title="Understand our Terms of Use">Terms of Use</a> | <a href="/about/terms-of-use.php#limitation-liability" title="Our Limitation of Liability explained">Limitation of Liability</a>
			</nav>
